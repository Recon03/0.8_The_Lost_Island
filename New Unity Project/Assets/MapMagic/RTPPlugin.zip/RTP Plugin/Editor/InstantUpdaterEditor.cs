using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;

//using Plugins;

namespace MapMagic 
{
	[CustomEditor(typeof(InstantUpdater))]
	public class InstantUpdaterEditor : Editor
	{
		private ReliefTerrain rtp;

		public override void OnInspectorGUI ()
		{
			InstantUpdater script = (InstantUpdater)target;

			EditorGUILayout.BeginVertical();

			script.enabledEditor = EditorGUILayout.ToggleLeft("Enabled in Editor", script.enabledEditor);
			script.enabledPlaymode = EditorGUILayout.ToggleLeft("Enabled in Playmode", script.enabledPlaymode);
			
			if (EditorApplication.isPlayingOrWillChangePlaymode)
			{
				if (script.enabledPlaymode) Refresh();
			}
			else
			{
				if (script.enabledEditor) Refresh();
			}
			
			if (GUILayout.Button("Update Now")) Refresh();
			
			EditorGUILayout.EndVertical();

		}

		public void Refresh ()
		{
			Profiler.BeginSample("Instant Updater: MMWG to RTP");
			foreach (Chunk chunk in MapMagic.instance.terrains.Objects())
			{
				if (rtp==null) rtp = MapMagic.instance.GetComponent<ReliefTerrain>();
				Material mat = chunk.terrain.materialTemplate;

				rtp.RefreshTextures(mat);
				rtp.globalSettingsHolder.Refresh(mat, rtp);
			}
			Profiler.EndSample();
		}
	}
}