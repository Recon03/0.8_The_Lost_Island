using UnityEngine;
using System.Collections;

namespace MapMagic
{
	public class InstantUpdater : MonoBehaviour 
	{
		public bool enabledEditor = true;
		public bool enabledPlaymode;
	}
}
